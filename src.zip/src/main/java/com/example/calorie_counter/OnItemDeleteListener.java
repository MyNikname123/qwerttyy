package com.example.calorie_counter;

public interface OnItemDeleteListener {
    void onItemDeleted();
}
