package com.example.calorie_counter;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class fragment1 extends Fragment implements OnItemDeleteListener {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private List<itemfrag1> items = new ArrayList<>();
    private String mParam1;
    private String mParam2;
    TextView textView, textView2;
    TextView caloriesCountTextView;

    public static fragment1 newInstance(String param1, String param2) {
        fragment1 fragment = new fragment1();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // начальная инициализация списка
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment1, container, false);

        // Бегущая строка калорий в меню
        caloriesCountTextView = view.findViewById(R.id.CaloriesCount);
        caloriesCountTextView.setSelected(true);

        textView = view.findViewById(R.id.date_textview);
        textView2 = view.findViewById(R.id.date);

        // Дата главного меню rectangle_round
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EE, dd.MM.yy");
        String dateTime = simpleDateFormat.format(calendar.getTime());

        // Преобразуем первую букву в заглавную
        if (!dateTime.isEmpty()) {
            dateTime = Character.toUpperCase(dateTime.charAt(0)) + dateTime.substring(1);
        }
        textView.setText(dateTime);
        textView2.setText(dateTime);
        setInitialData(getContext());
        RecyclerView recyclerView = view.findViewById(R.id.frag1_list_calories);
        // создаем адаптер
        itemAdapter_frag1 adapter = new itemAdapter_frag1(getContext(), items);
        // устанавливаем слушатель
        adapter.setOnItemDeleteListener(this);
        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        int totalCalories = calculateTotalCalories();
        caloriesCountTextView.setText(String.valueOf(totalCalories) + " Ккал");
        return view;
    }
    private void setInitialData(Context context){
        Integer caloriesSum = 0;
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        String currentDate = sdf.format(calendar.getTime());
        String fileName = "bd_" + currentDate + ".txt";
        String subDirectoryName = "BD";
        File subDirectory = new File(context.getFilesDir(), subDirectoryName);
        File file = new File(subDirectory, fileName);
        if (file.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] data = line.split("#");
                    if (data.length == 5) {
                        String title = data[0];
                        String type = data[1];
                        Integer calories = Integer.parseInt(data[2]);
                        Integer count = Integer.parseInt(data[3]);
                        int id = Integer.parseInt(data[4]);
                        items.add(new itemfrag1(title, count, type, calories, id));
                    }
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public static void DeleteItemOfDay(Context context, itemfrag1 item, OnItemDeleteListener itemDeleteListener){
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        String currentDate = sdf.format(Calendar.getInstance().getTime());
        String fileName = "bd_" + currentDate + ".txt";
        String subDirectoryName = "BD";
        File subDirectory = new File(context.getFilesDir(), subDirectoryName);
        File file = new File(subDirectory, fileName);
        if (file.exists()) {
            List<String> lines = new ArrayList<>();
            try {
                // Чтение содержимого файла и поиск строки для удаления
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] data = line.split("#");
                    if (data.length == 5) {
                        String title = data[0];
                        String type = data[1];
                        Integer calories = Integer.parseInt(data[2]);
                        Integer count = Integer.parseInt(data[3]);
                        int id = Integer.parseInt(data[4]);
                        // Проверка соответствия данных объекту itemfrag1
                        if (count.equals(item.getCount()) && id == item.getImage()) {
                            // Если строка соответствует объекту, не добавляем ее в список lines
                            continue;
                        }
                    }
                    lines.add(line);
                }
                reader.close();
                // Перезапись файла без удаленной строки
                FileWriter writer = new FileWriter(file);
                for (String newLine : lines) {
                    writer.write(newLine + "\n");
                }
                writer.close();
                // Уведомляем слушателя о том, что элемент был удален
                if (itemDeleteListener != null) {
                    itemDeleteListener.onItemDeleted();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private int calculateTotalCalories() {
        int totalCalories = 0;
        for (itemfrag1 item : items) {
            totalCalories += item.getCountCalories()*item.getCount()/100;
        }
        return totalCalories;
    }
    @Override
    public void onItemDeleted() {
        // Повторно вычисляем общее количество калорий и устанавливаем его в TextView
        int totalCalories = calculateTotalCalories();
        caloriesCountTextView.setText(String.valueOf(totalCalories) + " Ккал");
    }
}
