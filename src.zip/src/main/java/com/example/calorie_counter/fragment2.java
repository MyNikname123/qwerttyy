package com.example.calorie_counter;

import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import lombok.SneakyThrows;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link fragment2#newInstance} factory method to
 * create an instance of this fragment.
 */
public class fragment2 extends Fragment {
    TextView textView;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public fragment2() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment fragment2.
     */
    // TODO: Rename and change types and number of parameters
    public static fragment2 newInstance(String param1, String param2) {
        fragment2 fragment = new fragment2();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment2, container, false);

        RecyclerView rvItem = view.findViewById(R.id.search_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        DateItem_Adapter itemAdapter = new DateItem_Adapter(buildItemList());
        rvItem.setAdapter(itemAdapter);
        rvItem.setLayoutManager(layoutManager);
        // Настройка SearchView
//        SearchView searchView = view.findViewById(R.id.SearchView);
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                return false;
//            }
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                if (listItemfrag2 != null) {
//                    ListItemfrag3 filteredList = listItemfrag3.filter(newText);
//                    adapter.updateData(filteredList);
//                }
//                return true;
//            }
//        });
        return view;
    }

    private List<DateItem> buildItemList() {
        List<DateItem> itemList = new ArrayList<>();
        // Получаем список файлов в подкаталоге "BD"
        File bdDirectory = new File(getContext().getFilesDir(), "BD");
        File[] files = bdDirectory.listFiles();
        if (files != null) {
            // Проходим по каждому файлу
            for (File file : files) {
                // Получаем дату из имени файла
                String fileName = file.getName();
                String[] parts = fileName.split("_");
                if (parts.length == 2) {
                    String datePart = parts[1].split("\\.")[0]; // Извлекаем день месяц год из имени файла
                    SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
                    try {
                        Date date = sdf.parse(datePart);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yy");
                        String dateTime = dateFormat.format(calendar.getTime());
                        // Создаем элемент списка дат на основе найденного файла и его даты
                        itemList.add(new DateItem(dateTime, buildSubItemListFromFile(file)));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return itemList;
    }
    //Функция для заполнения калорий:
    @SneakyThrows
    private List<itemfrag2> buildSubItemListFromFile(File file) {
        List<itemfrag2> subItemList = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("#");
                if (data.length == 5) {
                    String title = data[0];
                    String type = data[1];
                    String count = data[2];
                    String countCalories = data[3];
                    int imageResource = Integer.parseInt(data[4]);
                    subItemList.add(new itemfrag2(title, count+type, countCalories, imageResource));
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return subItemList;
    }
}
