package com.example.calorie_counter;

import static com.example.calorie_counter.R.layout.frag3_item;
import static com.example.calorie_counter.fragment3.writeToDay;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;


public class itemAdapter_frag3 extends RecyclerView.Adapter<itemAdapter_frag3.ViewHolder>{
    private final LayoutInflater inflater;
    private final ListItemfrag3 items;
    private final ListItemfrag3 filteredItems;
    private Context context;
    private int[] iconsResources;

    itemAdapter_frag3(Context context, ListItemfrag3 items){
        this.items=items;
        this.filteredItems = new ListItemfrag3(); // Инициализируем отфильтрованный список
        this.filteredItems.getItemfrag3List().addAll(items.getItemfrag3List()); // Копируем все элементы из основного списка
        this.inflater=LayoutInflater.from(context);
        this.context = context;
        this.iconsResources = new int[300];
        for (int i = 1; i < iconsResources.length; i++) {
            iconsResources[i] = context.getResources().getIdentifier("ic" + i, "drawable", context.getPackageName());
        }
    }

    @Override
    public itemAdapter_frag3.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(frag3_item, parent, false);
        return new ViewHolder(view);
    }

    public void updateData(ListItemfrag3 filteredList) {
        filteredItems.getItemfrag3List().clear(); // Очищаем отфильтрованный список
        filteredItems.getItemfrag3List().addAll(filteredList.getItemfrag3List()); // Заменяем его отфильтрованными данными
        notifyDataSetChanged(); // Обновляем отображение списка
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        itemfrag3 item = filteredItems.get(position);
        holder.TitleView.setText(item.getName());
        holder.CountView.setText(item.getType());
        holder.CountCaloriesView.setText(item.getKalories().toString());
        holder.ImageView.setImageResource(iconsResources[item.getId()]);
        holder.AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView countEditText = holder.itemView.findViewById(R.id.Count);
                String counterText = countEditText.getText().toString().replaceAll("[^\\d]", "");
                writeToDay(context,item,counterText.isBlank()?0:Integer.parseInt(counterText));
                countEditText.setText(item.getType());
                // Добавляем вывод сообщения на экран с помощью Toast
                Toast.makeText(context,  item.getName() + ", успешно добавлен(а)! " , Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public int getItemCount() {
        return filteredItems.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView TitleView,CountView,CountCaloriesView;
        final ImageView ImageView;
        final AppCompatButton AddButton;

        ViewHolder(View view){
            super(view);
            TitleView = view.findViewById(R.id.Name_product);
            CountView = view.findViewById(R.id.Count);
            CountCaloriesView = view.findViewById(R.id.Calories_count);
            ImageView=view.findViewById(R.id.imageView);
            AddButton = view.findViewById(R.id.AddButtom);
        }
    }

}