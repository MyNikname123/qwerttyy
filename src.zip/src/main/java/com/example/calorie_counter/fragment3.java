package com.example.calorie_counter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import lombok.SneakyThrows;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link fragment3#newInstance} factory method to
 * create an instance of this fragment.
 */
public class fragment3 extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment fragment3.
     */
    // TODO: Rename and change types and number of parameters
    public static fragment3 newInstance(String param1, String param2) {
        fragment3 fragment = new fragment3();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment3, container, false);
        ListItemfrag3 listItemfrag3 = new ListItemfrag3();
        setInitialData(listItemfrag3);
        RecyclerView recyclerView = view.findViewById(R.id.search_list);
        // создаем адаптер
        itemAdapter_frag3 adapter = new itemAdapter_frag3(getContext(), listItemfrag3);
        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        // Настройка SearchView
        SearchView searchView = view.findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (listItemfrag3 != null) {
                    ListItemfrag3 filteredList = listItemfrag3.filter(newText);
                    adapter.updateData(filteredList);
                }
                return true;
            }
        });

        return view;
    }
    private void setInitialData(ListItemfrag3 listItemfrag3){
        listItemfrag3.add(createProd(1, "Свинина", "гр.", 484));
        listItemfrag3.add(createProd(2, "Говядина", "гр.", 191));
        listItemfrag3.add(createProd(3, "Баранина", "гр.", 201));
        listItemfrag3.add(createProd(4, "Телятина", "гр.", 91));
        listItemfrag3.add(createProd(5, "Кролик", "гр.", 197));
        listItemfrag3.add(createProd(6, "Курица", "гр.", 161));
        listItemfrag3.add(createProd(7, "Индейка", "гр.", 192));
        listItemfrag3.add(createProd(8, "Цыплята", "гр.", 159));
        listItemfrag3.add(createProd(9, "Утки", "гр.", 348));
        listItemfrag3.add(createProd(10, "Гуси", "гр.", 359));
        listItemfrag3.add(createProd(11, "Колбаса вареная 'Докторская'", "гр.", 257));
        listItemfrag3.add(createProd(12, "Колбаса вареная 'Любительская'", "гр.", 311));
        listItemfrag3.add(createProd(13, "Колбаса вареная 'Молочная'", "гр.", 243));
        listItemfrag3.add(createProd(14, "Колбаса полукопченая 'Любительская'", "гр.", 428));
        listItemfrag3.add(createProd(15, "Колбаса полукопченая 'Московская'", "гр.", 402));
        listItemfrag3.add(createProd(16, "Колбаса полукопченая 'Сервелат'", "гр.", 423));
        listItemfrag3.add(createProd(17, "Колбаса сырокопченая 'Любительская'", "гр.", 511));
        listItemfrag3.add(createProd(18, "Колбаса сырокопченая 'Московская'", "гр.", 476));
        listItemfrag3.add(createProd(19, "Колбаса сырокопченая 'Сервелат'", "гр.", 453));
        listItemfrag3.add(createProd(20, "Салями", "гр.", 576));
        listItemfrag3.add(createProd(21, "Кровянка", "гр.", 261));
        listItemfrag3.add(createProd(22, "Колбаски охотничьи", "гр.", 325));
        listItemfrag3.add(createProd(23, "Сосиски куриные", "гр.", 242));
        listItemfrag3.add(createProd(24, "Сосиски свиные", "гр.", 284));
        listItemfrag3.add(createProd(25, "Сосиски говяжьи", "гр.", 229));
        listItemfrag3.add(createProd(26, "Горбуша", "гр.", 151));
        listItemfrag3.add(createProd(27, "Лосось", "гр.", 200));
        listItemfrag3.add(createProd(28, "Минтай", "гр.", 67));
        listItemfrag3.add(createProd(29, "Кета", "гр.", 138));
        listItemfrag3.add(createProd(30, "Камбала", "гр.", 86));
        listItemfrag3.add(createProd(31, "Килька", "гр.", 142));
        listItemfrag3.add(createProd(32, "Корюшка", "гр.", 93));
        listItemfrag3.add(createProd(33, "Навага", "гр.", 78));
        listItemfrag3.add(createProd(34, "Сельдь", "гр.", 248));
        listItemfrag3.add(createProd(35, "Семга", "гр.", 222));
        listItemfrag3.add(createProd(36, "Скумбрия", "гр.", 158));
        listItemfrag3.add(createProd(37, "Форель", "гр.", 99));
        listItemfrag3.add(createProd(38, "Тунец", "гр.", 95));
        listItemfrag3.add(createProd(39, "Ставрида", "гр.", 119));
        listItemfrag3.add(createProd(40, "Икра кеты", "гр.", 250));
        listItemfrag3.add(createProd(41, "Икра минтая", "гр.", 127));
        listItemfrag3.add(createProd(42, "Икра осетровая", "гр.", 201));
        listItemfrag3.add(createProd(43, "Икра лещевая", "гр.", 144));
        listItemfrag3.add(createProd(44, "Кальмар", "гр.", 77));
        listItemfrag3.add(createProd(45, "Крабовые палочки", "гр.", 73));
        listItemfrag3.add(createProd(46, "Креветка", "гр.", 85));
        listItemfrag3.add(createProd(47, "Раки вареные", "гр.", 96));
        listItemfrag3.add(createProd(48, "Осьминог", "гр.", 74));
        listItemfrag3.add(createProd(49, "Мидии отварные", "гр.", 53));
        listItemfrag3.add(createProd(50, "Белые свежие", "гр.", 32));
        listItemfrag3.add(createProd(51, "Белые сушеные", "гр.", 277));
        listItemfrag3.add(createProd(52, "Лисички свежие", "гр.", 22));
        listItemfrag3.add(createProd(53, "Лисички сушеные", "гр.", 268));
        listItemfrag3.add(createProd(54, "Опята свежие", "гр.", 25));
        listItemfrag3.add(createProd(55, "Шампиньоны свежие", "гр.", 29));
        listItemfrag3.add(createProd(56, "Маслята свежие", "гр.", 12));
        listItemfrag3.add(createProd(57, "Вешенки свежие", "гр.", 34));
        listItemfrag3.add(createProd(58, "Куриное яйцо", "гр.", 153));
        listItemfrag3.add(createProd(59, "Перепелиное яйцо", "гр.", 170));
        listItemfrag3.add(createProd(60, "Утиное яйцо", "гр.", 176));
        listItemfrag3.add(createProd(61, "Омлет", "гр.", 181));
        listItemfrag3.add(createProd(62, "Масло растительное льняное", "мл.", 898));
        listItemfrag3.add(createProd(63, "Масло растительное подсолнечное", "мл.", 899));
        listItemfrag3.add(createProd(64, "Масло растительное оливковое", "мл.", 898));
        listItemfrag3.add(createProd(65, "Масло сливочное 82,5%", "гр.", 747));
        listItemfrag3.add(createProd(66, "Масло топленое", "гр.", 885));
        listItemfrag3.add(createProd(67, "Майонез 67%", "гр.", 624));
        listItemfrag3.add(createProd(68, "Молоко 0%", "мл.", 34));
        listItemfrag3.add(createProd(69, "Молоко 1%", "мл.", 43));
        listItemfrag3.add(createProd(70, "Молоко 2,5%", "мл.", 53));
        listItemfrag3.add(createProd(71, "Молоко 3,2%", "мл.", 58));
        listItemfrag3.add(createProd(72, "Молоко сухое цельное", "гр.", 477));
        listItemfrag3.add(createProd(73, "Молоко сгущенное", "гр.", 139));
        listItemfrag3.add(createProd(74, "Кефир 0%", "мл.", 29));
        listItemfrag3.add(createProd(75, "Кефир 1%", "мл.", 37));
        listItemfrag3.add(createProd(76, "Кефир 2,5%", "мл.", 51));
        listItemfrag3.add(createProd(77, "Кефир 3,2%", "мл.", 57));
        listItemfrag3.add(createProd(78, "Сметана 10%", "гр.", 118));
        listItemfrag3.add(createProd(79, "Сметана 15%", "гр.", 163));
        listItemfrag3.add(createProd(80, "Сметана 20%", "гр.", 208));
        listItemfrag3.add(createProd(81, "Творог жирный", "гр.", 236));
        listItemfrag3.add(createProd(82, "Творог нежирный", "гр.", 89));
        listItemfrag3.add(createProd(83, "Творог полужирный", "гр.", 156));
        listItemfrag3.add(createProd(84, "Ряженка 2,5%", "мл.", 53));
        listItemfrag3.add(createProd(85, "Ряженка 4,0%", "мл.", 68));
        listItemfrag3.add(createProd(86, "Йогурт 1,5%", "мл.", 65));
        listItemfrag3.add(createProd(87, "Йогурт 3,2%", "мл.", 87));
        listItemfrag3.add(createProd(88, "Сливки 10%", "мл.", 121));
        listItemfrag3.add(createProd(89, "Сливки 20%", "мл.", 209));
        listItemfrag3.add(createProd(90, "Сыр сулугуни", "гр.", 293));
        listItemfrag3.add(createProd(91, "Сыр российский", "гр.", 366));
        listItemfrag3.add(createProd(92, "Сыр пошехонский", "гр.", 348));
        listItemfrag3.add(createProd(93, "Овсяная крупа", "гр.", 342));
        listItemfrag3.add(createProd(94, "Кукурузная крупа", "гр.", 328));
        listItemfrag3.add(createProd(95, "Ячневая крупа", "гр.", 313));
        listItemfrag3.add(createProd(96, "Перловая крупа", "гр.", 315));
        listItemfrag3.add(createProd(97, "Манная крупа", "гр.", 333));
        listItemfrag3.add(createProd(98, "Гречневая крупа", "гр.", 350));
        listItemfrag3.add(createProd(99, "Пшеничная крупа", "гр.", 342));
        listItemfrag3.add(createProd(100, "Рис белый длиннозерный", "гр.", 365));
        listItemfrag3.add(createProd(101, "Хлеб пшеничный", "гр.", 246));
        listItemfrag3.add(createProd(102, "Хлеб ржаной", "гр.", 210));
        listItemfrag3.add(createProd(103, "Сухари пшеничные", "гр.", 327));
        listItemfrag3.add(createProd(104, "Лаваш армянский", "гр.", 239));
        listItemfrag3.add(createProd(105, "Батон нарезной", "гр.", 261));
        listItemfrag3.add(createProd(106, "Баранки", "гр.", 342));
        listItemfrag3.add(createProd(107, "Сушки", "гр.", 335));
        listItemfrag3.add(createProd(108, "Булочка", "гр.", 218));
        listItemfrag3.add(createProd(109, "Огурцы", "гр.", 15));
        listItemfrag3.add(createProd(110, "Томаты", "гр.", 19));
        listItemfrag3.add(createProd(111, "Картофель вареный", "гр.", 80));
        listItemfrag3.add(createProd(112, "Картофель молодой", "гр.", 57));
        listItemfrag3.add(createProd(113, "Морковь", "гр.", 29));
        listItemfrag3.add(createProd(114, "Лук репчатый", "гр.", 41));
        listItemfrag3.add(createProd(115, "Редис", "гр.", 22));
        listItemfrag3.add(createProd(116, "Кабачки", "гр.", 30));
        listItemfrag3.add(createProd(117, "Баклажаны", "гр.", 22));
        listItemfrag3.add(createProd(118, "Свекла", "гр.", 46));
        listItemfrag3.add(createProd(119, "Капуста белокочанная", "гр.", 31));
        listItemfrag3.add(createProd(120, "Фасоль", "гр.", 36));
        listItemfrag3.add(createProd(121, "Редька", "гр.", 33));
        listItemfrag3.add(createProd(122, "Перец сладкий", "гр.", 25));
        listItemfrag3.add(createProd(123, "Бананы", "гр.", 87));
        listItemfrag3.add(createProd(124, "Апельсины", "гр.", 38));
        listItemfrag3.add(createProd(125, "Яблоки", "гр.", 48));
        listItemfrag3.add(createProd(126, "Груша", "гр.", 41));
        listItemfrag3.add(createProd(127, "Персики", "гр.", 42));
        listItemfrag3.add(createProd(128, "Абрикосы", "гр.", 44));
        listItemfrag3.add(createProd(129, "Ананас", "гр.", 49));
        listItemfrag3.add(createProd(130, "Киви", "гр.", 46));
        listItemfrag3.add(createProd(131, "Лимон", "гр.", 30));
        listItemfrag3.add(createProd(132, "Хурма", "гр.", 61));
        listItemfrag3.add(createProd(133, "Мандарин", "гр.", 39));
        listItemfrag3.add(createProd(134, "Петрушка", "гр.", 45));
        listItemfrag3.add(createProd(135, "Лук (перо)", "гр.", 21));
        listItemfrag3.add(createProd(136, "Салат", "гр.", 15));
        listItemfrag3.add(createProd(137, "Щавель", "гр.", 29));
        listItemfrag3.add(createProd(138, "Шпинат", "гр.", 22));
        listItemfrag3.add(createProd(139, "Укроп", "гр.", 40));
        listItemfrag3.add(createProd(140, "Кинза", "гр.", 23));
        listItemfrag3.add(createProd(141, "Вишня", "гр.", 46));
        listItemfrag3.add(createProd(142, "Черешня", "гр.", 54));
        listItemfrag3.add(createProd(143, "Клубника", "гр.", 30));
        listItemfrag3.add(createProd(144, "Земляника", "гр.", 40));
        listItemfrag3.add(createProd(145, "Смородина черная", "гр.", 38));
        listItemfrag3.add(createProd(146, "Малина", "гр.", 43));
        listItemfrag3.add(createProd(147, "Виноград", "гр.", 73));
        listItemfrag3.add(createProd(148, "Кизил", "гр.", 42));
        listItemfrag3.add(createProd(149, "Ежевика", "гр.", 31));
        listItemfrag3.add(createProd(150, "Арахис", "гр.", 555));
        listItemfrag3.add(createProd(151, "Семя подсолнечника", "гр.", 582));
        listItemfrag3.add(createProd(152, "Грецкий орех", "гр.", 662));
        listItemfrag3.add(createProd(153, "Кешью", "гр.", 647));
        listItemfrag3.add(createProd(154, "Миндаль", "гр.", 643));
        listItemfrag3.add(createProd(155, "Фундук", "гр.", 701));
        listItemfrag3.add(createProd(156, "Фисташки", "гр.", 555));
        listItemfrag3.add(createProd(157, "Изюм", "гр.", 273));
        listItemfrag3.add(createProd(158, "Курага", "гр.", 270));
        listItemfrag3.add(createProd(159, "Финики", "гр.", 277));
        listItemfrag3.add(createProd(160, "Чернослив", "гр.", 262));
        listItemfrag3.add(createProd(161, "Яблоки сушеные", "гр.", 275));
        listItemfrag3.add(createProd(162, "Печенье сдобное", "гр.", 447));
        listItemfrag3.add(createProd(163, "Пряники", "гр.", 333));
        listItemfrag3.add(createProd(164, "Зефир", "гр.", 295));
        listItemfrag3.add(createProd(165, "Конфеты шоколадные", "гр.", 576));
        listItemfrag3.add(createProd(166, "Мармелад", "гр.", 289));
        listItemfrag3.add(createProd(167, "Ирис", "гр.", 384));
        listItemfrag3.add(createProd(168, "Пирожное слоеное", "гр.", 543));
        listItemfrag3.add(createProd(169, "Пирожное бисквитное", "гр.", 338));
        listItemfrag3.add(createProd(170, "Чай черный без сахара", "мл.", 0));
        listItemfrag3.add(createProd(171, "Чай зеленый без сахара", "мл.", 0));
        listItemfrag3.add(createProd(172, "Кофе с молоком", "мл.", 56));
        listItemfrag3.add(createProd(173, "Какао на молоке", "мл.", 377));
        listItemfrag3.add(createProd(174, "Хлебный квас", "мл.", 26));
        listItemfrag3.add(createProd(175, "Лимонад", "мл.", 24));
        listItemfrag3.add(createProd(176, "Яблочный сок", "мл.", 42));
        listItemfrag3.add(createProd(177, "Апельсиновый сок", "мл.", 36));
        listItemfrag3.add(createProd(178, "Вишневый сок", "мл.", 49));
        listItemfrag3.add(createProd(179, "Морковный сок", "мл.", 31));
        listItemfrag3.add(createProd(180, "Пиво безалкогольное", "мл.", 22));
        listItemfrag3.add(createProd(181, "Энергетический напиток", "мл.", 47));
        listItemfrag3.add(createProd(182, "Шампанское", "мл.", 88));
        listItemfrag3.add(createProd(183, "Водка", "мл.", 234));
        listItemfrag3.add(createProd(184, "Коньяк", "мл.", 240));
        listItemfrag3.add(createProd(185, "Виски", "мл.", 222));
        listItemfrag3.add(createProd(186, "Ром", "мл.", 217));
        listItemfrag3.add(createProd(187, "Ликер", "мл.", 344));
        listItemfrag3.add(createProd(188, "Вино сухое", "мл.", 65));
        listItemfrag3.add(createProd(189, "Вино полусухое", "мл.", 79));
        listItemfrag3.add(createProd(190, "Вино десертное", "мл.", 175));
        listItemfrag3.add(createProd(191, "Вино полусладкое", "мл.", 88));
        listItemfrag3.add(createProd(192, "Вино столовое", "мл.", 67));
        listItemfrag3.add(createProd(193, "Пиво 3,0%", "мл.", 37));
        listItemfrag3.add(createProd(194, "Пиво 4,5%", "мл.", 45));
        listItemfrag3.add(createProd(195, "Пиво темное", "мл.", 39));

    }
    // Вспомогательный метод для создания экземпляра Prod
    private itemfrag3 createProd(Integer id, String name, String  type, Integer kalories) {
        itemfrag3 itemfrag3 = new itemfrag3();
        itemfrag3.setId(id);
        itemfrag3.setName(name);
        itemfrag3.setType(type);
        itemfrag3.setKalories(kalories);
        return itemfrag3;
    }
    @SneakyThrows
    public static void writeToDay(Context context, itemfrag3 itemfrag3, Integer count) {
        // Получаем текущую дату
        SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        String subDirectoryName = "BD";
        File subDirectory = new File(context.getFilesDir(), subDirectoryName);
        if (!subDirectory.exists()) {
            subDirectory.mkdir(); // Создаем подкаталог, если его нет
        }
        String fileName = "bd_" + currentDate + ".txt";
        // Получаем или создаем файл
        File file = new File(subDirectory, fileName);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            // Открываем файл для записи
            FileWriter writer = new FileWriter(file, true);
            // Записываем данные о продукте в файл
            writer.append(itemfrag3.getName() + "#"
                            + itemfrag3.getType() + "#"
                            + itemfrag3.getKalories() + "#"
                            + count + '#'
                            + itemfrag3.getId() + "\n");
            // Закрываем файл
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
