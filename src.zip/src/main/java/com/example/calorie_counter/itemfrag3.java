package com.example.calorie_counter;

import lombok.ToString;

@ToString
public class itemfrag3 {
    Integer id;
    String name;
    String type;
    Integer kalories;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setKalories(Integer kalories) {
        this.kalories = kalories;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public Integer getKalories() {
        return kalories;
    }

}
