package com.example.calorie_counter;

public class itemfrag1 {
    private String title;
    private Integer count;
    private String type;
    private Integer countCalories;
    int image;

    public int getImage() {
        return image;
    }

    public itemfrag1 (String title, Integer count, String type, Integer countCalories, int image)
    {
        this.image=image;
        this.title=title;
        this.count=count;
        this.type=type;
        this.countCalories=countCalories;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getCountCalories() {
        return countCalories;
    }
    public void setCountCalories(Integer countCalories) {
        this.countCalories = countCalories;
    }
    public int getimage() {
        return this.image;
    }
    public void setimage(int image) {
        this.image=image;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
