package com.example.calorie_counter;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Getter
@Setter
@ToString
@Component
public class ListItemfrag3 {
    private List<itemfrag3> itemfrag3List;

    public ListItemfrag3() {
        this.itemfrag3List = new ArrayList<>();
    }
    public void add(itemfrag3 itemfrag3) {
        itemfrag3List.add(itemfrag3);
    }

    public List<itemfrag3> getItemfrag3List() {
        return itemfrag3List;
    }

    public ListItemfrag3 filter(String query) {
        ListItemfrag3 filteredList = new ListItemfrag3();
        for (itemfrag3 itemfrag3 : itemfrag3List) {
            if (itemfrag3.getName().toLowerCase(Locale.getDefault()).contains(query.toLowerCase(Locale.getDefault()))) {
                filteredList.add(itemfrag3);
            }
        }
        return filteredList;
    }
    public void displayAllProds() {
        for (itemfrag3 itemfrag3 : itemfrag3List) {
            System.out.println(itemfrag3);
        }
    }
    public int size() {
        return itemfrag3List.size();
    }
    public itemfrag3 get(int number) {
        for (itemfrag3 itemfrag3 : itemfrag3List) {
            if (itemfrag3List.indexOf(itemfrag3) == number) {
                return itemfrag3;
            }
        }
        return null;
    }
}
