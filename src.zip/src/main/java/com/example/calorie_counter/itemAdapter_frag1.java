package com.example.calorie_counter;

import static com.example.calorie_counter.fragment1.DeleteItemOfDay;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class itemAdapter_frag1 extends RecyclerView.Adapter<itemAdapter_frag1.ViewHolder>{
    private final LayoutInflater inflater;
    private final List<itemfrag1> items;
    private int[] iconsResources;
    private Context context;
    private OnItemDeleteListener itemDeleteListener;

    itemAdapter_frag1(Context context, List<itemfrag1> items){
        this.items=items;
        this.inflater=LayoutInflater.from(context);
        this.iconsResources = new int[300];
        this.context  = context;
        for (int i = 1; i < iconsResources.length; i++) {
            iconsResources[i] = context.getResources().getIdentifier("ic" + i, "drawable", context.getPackageName());
        }
    }
    @Override
    public itemAdapter_frag1.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.frag1_item, parent, false);
        return new ViewHolder(view);
    }
    public void setOnItemDeleteListener(OnItemDeleteListener listener) {
        this.itemDeleteListener = listener;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        itemfrag1 item = items.get(position);
        holder.TitleView.setText(item.getTitle());
        holder.CountView.setText(item.getCount().toString()+item.getType());
        holder.CountCaloriesView.setText(item.getCountCalories().toString());
        holder.ImageView.setImageResource(iconsResources[item.getimage()]);
        // Добавление действия при нажатии на кнопку удаления
        holder.DelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteItemOfDay(context,item, itemDeleteListener);
                items.remove(item);
                notifyDataSetChanged();
                // Уведомляем слушателя об удалении элемента
                if (itemDeleteListener != null) {
                    itemDeleteListener.onItemDeleted();
                }
            }
        });
    }
    private int calculateTotalCalories() {
        int totalCalories = 0;
        for (itemfrag1 item : items) {
            totalCalories += item.getCountCalories() * item.getCount() / 100;
        }
        return totalCalories;
    }
    @Override
    public int getItemCount() {
        return items.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView TitleView,CountView,CountCaloriesView;
        final ImageView ImageView;
        final Button DelButton;

        ViewHolder(View view){
            super(view);
            TitleView = view.findViewById(R.id.Name_product);
            CountView = view.findViewById(R.id.Count);
            CountCaloriesView = view.findViewById(R.id.Calories_count);
            ImageView=view.findViewById(R.id.imageView);
            DelButton = view.findViewById(R.id.DelButtom);
        }
    }}